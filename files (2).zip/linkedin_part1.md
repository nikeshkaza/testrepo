# Insurance Policy Similarity Matching System - Part 1: Overview & Preprocessing

*A Production-Ready AI System for Underwriter Risk Assessment*

---

## 🎯 Business Problem

When underwriters receive new insurance policy applications, they need to:
- Assess risk accurately based on historical data
- Price policies competitively
- Reference similar past policies for guidance
- Make consistent decisions across submissions

**Solution**: An AI-powered similarity matching system that finds the top 3 most relevant historical policies using advanced ML techniques including **sentence transformers** and **GPT-4o integration** for enhanced semantic understanding.

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      NEW POLICY SUBMISSION                       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FEATURE EXTRACTION                            │
│  • Numerical Features (16): TIV, Revenue, Employees, etc.       │
│  • Categorical Features (32): Product, Industry, Location        │
│  • Text Features: Policy descriptions, company info             │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                     PREPROCESSING PIPELINE                       │
│  1. Feature Engineering (ratios, age, log transforms)           │
│  2. Sentence Transformer Embeddings (text → vectors)            │
│  3. Categorical Encoding (frequency + label)                    │
│  4. Robust Scaling (handles outliers)                           │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                  DIMENSIONALITY REDUCTION                        │
│  • PCA: Variance retention                                      │
│  • UMAP: Non-linear structure preservation                      │
│  • Combined numerical + semantic embeddings                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CLUSTERING & SIMILARITY                       │
│  • K-Means clustering for policy segmentation                   │
│  • K-NN for fast similarity search                              │
│  • Hybrid scoring: distance + semantic similarity               │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    TOP 3 SIMILAR POLICIES                        │
│  Rank 1: Score 0.87 | TIV: $2.3M | Same Industry                │
│  Rank 2: Score 0.82 | TIV: $2.1M | Similar Risk Profile         │
│  Rank 3: Score 0.79 | TIV: $2.5M | Geographic Proximity         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│              EXPLAINABILITY & INSIGHTS (GPT-4o)                  │
│  • SHAP feature importance                                      │
│  • GPT-4o natural language explanations                         │
│  • Risk factor analysis                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## 💡 Enhanced Approach with Sentence Transformers & GPT-4o

### Why Sentence Transformers?

**Traditional Approach Limitations:**
- Categorical encoding loses semantic meaning
- Industry codes (e.g., "8062" vs "Healthcare") not linked
- Product descriptions treated as discrete categories

**Sentence Transformer Benefits:**
- Captures semantic similarity: "Healthcare" ≈ "Medical Services"
- Understands industry relationships automatically
- Better matching for similar but non-identical categories
- Works with policy descriptions and company information

### Why GPT-4o Integration?

**Use Cases:**
1. **Enhanced Explainability**: Natural language explanations of why policies match
2. **Risk Factor Extraction**: Identify key risk factors from text fields
3. **Smart Feature Engineering**: Generate domain-specific features
4. **Cluster Naming**: Auto-generate meaningful cluster labels

---

## 📊 Data Features

### Numerical Features (16)
```
DUNS_NUMBER_1          → Business identifier
policy_tiv             → Total insured value
Revenue                → Company revenue
highest_location_tiv   → Maximum location risk
POSTAL_CD              → Geographic code
LAT_NEW, LATIT         → Latitude (dual source)
LONG_NEW, LONGIT       → Longitude (dual source)
SIC_1                  → Industry classification
EMP_TOT                → Employee count
SLES_VOL               → Sales volume
YR_STRT                → Founding year
STAT_IND               → Status indicator
SUBS_IND               → Subsidiary flag
outliers               → Outlier detection flag
```

### Categorical Features (32)
```
Product Type           → Property, Casualty, Professional Liability
Sub Product            → General Liability, E&O, D&O
Industry               → NAIC codes and descriptions (multiple levels)
Portfolio              → Small, Medium, Large, Enterprise
Programme Type         → Standard, Package, Umbrella
Tail Classification    → Short Tail / Long Tail
Location & Producer    → Geographic and distribution details
```

### Text Features (NEW with Transformers)
```
Policy descriptions    → Free-text policy details
Company information    → Business description
Industry details       → Detailed industry context
Risk narratives        → Underwriter notes
```

---

## 🔧 Code Implementation - Part 1: Enhanced Preprocessing

### Installation

```bash
pip install sentence-transformers openai anthropic pandas numpy scikit-learn \
            umap-learn shap matplotlib seaborn plotly joblib
```

### Import Libraries

```python
import pandas as pd
import numpy as np
import warnings
from typing import Dict, List, Tuple, Optional
from datetime import datetime

# Core ML
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import silhouette_score, davies_bouldin_score

# Advanced components
from sentence_transformers import SentenceTransformer
import umap
import shap

# LLM integration
import openai  # for GPT-4o
import anthropic  # alternative for Claude

warnings.filterwarnings('ignore')
```

### Enhanced Preprocessor with Sentence Transformers

```python
class EnhancedInsurancePolicyPreprocessor:
    """
    Advanced preprocessor with semantic embeddings
    """
    
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        """
        Initialize with sentence transformer model
        
        Model options:
        - 'all-MiniLM-L6-v2': Fast, good quality (384 dims)
        - 'all-mpnet-base-v2': Best quality (768 dims)
        - 'paraphrase-multilingual-MiniLM-L12-v2': Multi-language
        """
        self.numerical_scaler = RobustScaler()
        self.categorical_encoders = {}
        self.feature_names = []
        self.is_fitted = False
        
        # Sentence transformer for semantic embeddings
        print(f"Loading sentence transformer: {model_name}...")
        self.sentence_model = SentenceTransformer(model_name)
        self.embedding_dim = self.sentence_model.get_sentence_embedding_dimension()
        print(f"✓ Model loaded. Embedding dimension: {self.embedding_dim}")
        
    def create_text_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create text features for embedding
        """
        df_text = df.copy()
        
        # Combine relevant text fields
        text_components = []
        
        # Product information
        if 'Product' in df.columns:
            text_components.append(df['Product'].fillna(''))
        if 'Sub Product' in df.columns:
            text_components.append(df['Sub Product'].fillna(''))
            
        # Industry information
        if 'Policy Industry Description' in df.columns:
            text_components.append(df['Policy Industry Description'].fillna(''))
        if '2012 NAIC Description' in df.columns:
            text_components.append(df['2012 NAIC Description'].fillna(''))
            
        # Business characteristics
        if 'Portfolio Segmentation' in df.columns:
            text_components.append(df['Portfolio Segmentation'].fillna(''))
        if 'Programme Type' in df.columns:
            text_components.append(df['Programme Type'].fillna(''))
            
        # Create combined text
        df_text['combined_text'] = ' | '.join([
            comp if isinstance(comp, str) else ' '.join(comp.astype(str))
            for comp in text_components
        ])
        
        return df_text
    
    def generate_embeddings(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """
        Generate sentence embeddings
        """
        print(f"Generating embeddings for {len(texts)} texts...")
        embeddings = self.sentence_model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=True,
            convert_to_numpy=True
        )
        print(f"✓ Embeddings generated. Shape: {embeddings.shape}")
        return embeddings
    
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create derived numerical features
        """
        df_eng = df.copy()
        
        # Financial ratios
        df_eng['tiv_per_location'] = (
            df_eng['policy_tiv'] / (df_eng['highest_location_tiv'] + 1)
        )
        df_eng['revenue_per_employee'] = (
            df_eng['Revenue'] / (df_eng['EMP_TOT'] + 1)
        )
        df_eng['sales_to_revenue_ratio'] = (
            df_eng['SLES_VOL'] / (df_eng['Revenue'] + 1)
        )
        
        # Company metrics
        current_year = datetime.now().year
        df_eng['company_age'] = current_year - df_eng['YR_STRT']
        df_eng['company_maturity'] = pd.cut(
            df_eng['company_age'],
            bins=[0, 5, 15, 50, 200],
            labels=['startup', 'growth', 'mature', 'established']
        )
        
        # Risk indicators
        df_eng['high_value_flag'] = (df_eng['policy_tiv'] > df_eng['policy_tiv'].quantile(0.75)).astype(int)
        df_eng['concentration_risk'] = df_eng['highest_location_tiv'] / (df_eng['policy_tiv'] + 1)
        
        # Geographic consistency
        df_eng['lat_consistency'] = np.abs(df_eng['LAT_NEW'] - df_eng['LATIT'])
        df_eng['long_consistency'] = np.abs(df_eng['LONG_NEW'] - df_eng['LONGIT'])
        df_eng['geo_quality_score'] = 1 / (1 + df_eng['lat_consistency'] + df_eng['long_consistency'])
        
        # Log transforms for skewed distributions
        for col in ['policy_tiv', 'Revenue', 'EMP_TOT', 'SLES_VOL']:
            if col in df_eng.columns:
                df_eng[f'log_{col}'] = np.log1p(df_eng[col])
        
        # Industry risk score (example - would be customized)
        high_risk_sics = [1731, 3571, 7372]  # Construction, Computers, Software
        df_eng['high_risk_industry'] = df_eng['SIC_1'].isin(high_risk_sics).astype(int)
        
        return df_eng
    
    def encode_categorical(
        self, 
        df: pd.DataFrame, 
        categorical_cols: List[str],
        fit: bool = True
    ) -> Tuple[pd.DataFrame, List[str]]:
        """
        Encode categorical variables
        """
        df_encoded = df.copy()
        encoded_features = []
        
        for col in categorical_cols:
            if col not in df.columns:
                continue
            
            # Frequency encoding
            if fit:
                freq_encoding = df[col].value_counts(normalize=True).to_dict()
                self.categorical_encoders[f'{col}_freq'] = freq_encoding
            
            freq_encoding = self.categorical_encoders.get(f'{col}_freq', {})
            df_encoded[f'{col}_freq'] = df[col].map(freq_encoding).fillna(0)
            encoded_features.append(f'{col}_freq')
            
            # Label encoding for low cardinality
            if df[col].nunique() < 50:
                if fit:
                    le = LabelEncoder()
                    le.fit(df[col].astype(str))
                    self.categorical_encoders[f'{col}_label'] = le
                
                le = self.categorical_encoders.get(f'{col}_label')
                if le is not None:
                    df_encoded[f'{col}_label'] = le.transform(df[col].astype(str))
                    encoded_features.append(f'{col}_label')
        
        return df_encoded, encoded_features
    
    def fit_transform(
        self,
        df: pd.DataFrame,
        numerical_cols: List[str],
        categorical_cols: List[str],
        use_embeddings: bool = True
    ) -> Tuple[np.ndarray, np.ndarray, pd.DataFrame]:
        """
        Complete preprocessing with embeddings
        
        Returns:
        --------
        X_numerical : array
            Scaled numerical features
        X_embeddings : array
            Sentence embeddings (if use_embeddings=True)
        df_processed : DataFrame
            Processed dataframe with all features
        """
        print("="*80)
        print("ENHANCED PREPROCESSING PIPELINE")
        print("="*80)
        
        # Engineer features
        print("\n1. Engineering features...")
        df_processed = self.engineer_features(df)
        
        # Generate embeddings
        X_embeddings = None
        if use_embeddings:
            print("\n2. Creating text features and embeddings...")
            df_with_text = self.create_text_features(df)
            X_embeddings = self.generate_embeddings(df_with_text['combined_text'].tolist())
        
        # Encode categorical
        print("\n3. Encoding categorical variables...")
        df_processed, cat_encoded_features = self.encode_categorical(
            df_processed, categorical_cols, fit=True
        )
        
        # Prepare numerical features
        engineered_num_cols = [
            'tiv_per_location', 'revenue_per_employee', 'sales_to_revenue_ratio',
            'company_age', 'concentration_risk', 'geo_quality_score',
            'high_value_flag', 'high_risk_industry'
        ]
        
        # Add log-transformed features
        log_cols = [f'log_{col}' for col in ['policy_tiv', 'Revenue', 'EMP_TOT', 'SLES_VOL'] 
                    if f'log_{col}' in df_processed.columns]
        
        num_cols_available = [col for col in numerical_cols if col in df_processed.columns]
        all_num_cols = num_cols_available + engineered_num_cols + log_cols
        
        # Handle missing values
        print("\n4. Handling missing values...")
        df_processed[all_num_cols] = df_processed[all_num_cols].fillna(
            df_processed[all_num_cols].median()
        )
        df_processed[cat_encoded_features] = df_processed[cat_encoded_features].fillna(0)
        
        # Scale numerical features
        print("\n5. Scaling numerical features...")
        X_numerical_scaled = self.numerical_scaler.fit_transform(df_processed[all_num_cols])
        X_categorical = df_processed[cat_encoded_features].values
        
        # Combine traditional features
        X_traditional = np.hstack([X_numerical_scaled, X_categorical])
        
        # Store feature names
        self.feature_names = all_num_cols + cat_encoded_features
        self.is_fitted = True
        
        print("\n" + "="*80)
        print("PREPROCESSING COMPLETE")
        print("="*80)
        print(f"Traditional features: {X_traditional.shape[1]}")
        if use_embeddings:
            print(f"Embedding features: {X_embeddings.shape[1]}")
            print(f"Total feature space: {X_traditional.shape[1] + X_embeddings.shape[1]}")
        print("="*80)
        
        return X_traditional, X_embeddings, df_processed
```

---

## 📈 Key Improvements Over Traditional Approach

### 1. **Semantic Understanding**
```
Traditional:  "Healthcare" ≠ "Medical Services"  (treated as different)
Enhanced:     "Healthcare" ≈ "Medical Services"  (similarity: 0.87)
```

### 2. **Better Product Matching**
```
Traditional:  "Professional Liability" vs "Errors & Omissions" → No connection
Enhanced:     Understands these are related insurance products
```

### 3. **Industry Intelligence**
```
Traditional:  SIC code 8062 → Just a number
Enhanced:     8062 → "Healthcare" → Related to hospitals, clinics, medical
```

### 4. **Richer Feature Space**
```
Traditional:  ~50 features (numerical + encoded categorical)
Enhanced:     ~50 traditional + 384 semantic embeddings = 434 dimensions
              More nuanced similarity matching
```

---

## 🎯 Next Steps

**Part 2** will cover:
- Advanced similarity search with hybrid scoring
- Clustering with combined features
- GPT-4o integration for explainability

**Part 3** will cover:
- SHAP explanations
- Evaluation metrics
- Production deployment

**Part 4** will cover:
- Complete code examples
- API integration
- Best practices

---

*Follow for Parts 2-4 coming next!*

#MachineLearning #Insurance #AI #DataScience #Underwriting #Python #NLP
