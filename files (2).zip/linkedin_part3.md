# Insurance Policy Similarity Matching System - Part 3: Evaluation & Explainability

*Comprehensive Model Validation with SHAP + Business Metrics*

---

## 📊 Evaluation Framework

### Multi-Level Validation Strategy

```
┌────────────────────────────────────────────────────────────┐
│  LEVEL 1: Clustering Quality (Mathematical)                │
│  → Silhouette Score, Davies-Bouldin Index                  │
└────────────────────────────────────────────────────────────┘
                           ↓
┌────────────────────────────────────────────────────────────┐
│  LEVEL 2: Similarity Matching Quality (System)             │
│  → Cluster/Product/Industry Consistency                    │
└────────────────────────────────────────────────────────────┘
                           ↓
┌────────────────────────────────────────────────────────────┐
│  LEVEL 3: Business Metrics (Domain-Specific)               │
│  → TIV Similarity, Risk Profile Match                      │
└────────────────────────────────────────────────────────────┘
                           ↓
┌────────────────────────────────────────────────────────────┐
│  LEVEL 4: User Validation (Human-in-the-loop)              │
│  → Underwriter Feedback, A/B Testing                       │
└────────────────────────────────────────────────────────────┘
```

---

## 💻 Code Implementation - Part 3

### Comprehensive Evaluation Suite

```python
class ModelEvaluator:
    """
    Complete evaluation framework for policy similarity system
    """
    
    def __init__(self, system: HybridPolicySimilaritySystem):
        self.system = system
        self.evaluation_results = {}
    
    def evaluate_clustering_quality(self) -> Dict[str, float]:
        """
        Level 1: Mathematical clustering metrics
        """
        print("="*80)
        print("LEVEL 1: CLUSTERING QUALITY EVALUATION")
        print("="*80)
        
        X = self.system.X_combined
        labels = self.system.cluster_labels
        
        # Silhouette Score (range: -1 to 1, higher is better)
        silhouette = silhouette_score(X, labels)
        
        # Davies-Bouldin Index (lower is better)
        davies_bouldin = davies_bouldin_score(X, labels)
        
        # Calinski-Harabasz Index (higher is better)
        calinski = calinski_harabasz_score(X, labels)
        
        # Inertia (within-cluster sum of squares)
        inertia = self.system.kmeans.inertia_
        
        results = {
            'silhouette_score': silhouette,
            'davies_bouldin_index': davies_bouldin,
            'calinski_harabasz_score': calinski,
            'inertia': inertia,
            'n_clusters': self.system.n_clusters
        }
        
        print(f"\nResults:")
        print(f"  Silhouette Score:        {silhouette:.3f}")
        print(f"    → Interpretation: {'Excellent' if silhouette > 0.7 else 'Good' if silhouette > 0.5 else 'Fair' if silhouette > 0.3 else 'Poor'}")
        print(f"  Davies-Bouldin Index:    {davies_bouldin:.3f}")
        print(f"    → Interpretation: {'Excellent' if davies_bouldin < 0.5 else 'Good' if davies_bouldin < 1.0 else 'Fair' if davies_bouldin < 1.5 else 'Poor'}")
        print(f"  Calinski-Harabasz Score: {calinski:.1f}")
        print(f"  Inertia:                 {inertia:.1f}")
        
        self.evaluation_results['clustering'] = results
        return results
    
    def evaluate_similarity_matching(self, n_samples: int = 200) -> Dict[str, float]:
        """
        Level 2: Similarity matching consistency
        """
        print("\n" + "="*80)
        print("LEVEL 2: SIMILARITY MATCHING EVALUATION")
        print("="*80)
        
        df = self.system.df_processed
        test_indices = np.random.choice(len(df), min(n_samples, len(df)), replace=False)
        
        cluster_consistency = []
        product_consistency = []
        industry_consistency = []
        portfolio_consistency = []
        avg_scores = []
        
        print(f"\nTesting on {len(test_indices)} random policies...")
        
        for idx in test_indices:
            query_policy = df.iloc[idx:idx+1]
            
            # Find similar
            result = self.system.find_similar(
                query_policy,
                numerical_features=['policy_tiv', 'Revenue', 'EMP_TOT'],  # simplified
                categorical_features=['Product', 'Sub Product'],
                top_n=3,
                explain=False
            )
            
            # Cluster consistency
            query_cluster = df.iloc[idx]['cluster']
            same_cluster = sum(1 for p in result['similar_policies'] 
                             if p['cluster'] == query_cluster)
            cluster_consistency.append(same_cluster / 3)
            
            # Product consistency
            if 'Product' in df.columns:
                query_product = df.iloc[idx]['Product']
                same_product = sum(1 for p in result['similar_policies'] 
                                 if p.get('product') == query_product)
                product_consistency.append(same_product / 3)
            
            # Industry consistency
            if 'Policy Industry Description' in df.columns:
                query_industry = df.iloc[idx]['Policy Industry Description']
                same_industry = sum(1 for p in result['similar_policies'] 
                                  if p.get('policy_industry_description') == query_industry)
                industry_consistency.append(same_industry / 3)
            
            # Average similarity scores
            avg_score = np.mean([p['overall_score'] for p in result['similar_policies']])
            avg_scores.append(avg_score)
        
        results = {
            'cluster_consistency_mean': np.mean(cluster_consistency),
            'cluster_consistency_std': np.std(cluster_consistency),
            'product_consistency_mean': np.mean(product_consistency) if product_consistency else 0,
            'industry_consistency_mean': np.mean(industry_consistency) if industry_consistency else 0,
            'avg_similarity_score': np.mean(avg_scores),
            'similarity_score_std': np.std(avg_scores)
        }
        
        print(f"\nResults:")
        print(f"  Cluster Consistency:  {results['cluster_consistency_mean']:.1%} ± {results['cluster_consistency_std']:.1%}")
        print(f"  Product Consistency:  {results['product_consistency_mean']:.1%}")
        print(f"  Industry Consistency: {results['industry_consistency_mean']:.1%}")
        print(f"  Avg Similarity Score: {results['avg_similarity_score']:.3f} ± {results['similarity_score_std']:.3f}")
        
        self.evaluation_results['similarity'] = results
        return results
    
    def evaluate_business_metrics(self, n_samples: int = 200) -> Dict[str, float]:
        """
        Level 3: Business-relevant similarity metrics
        """
        print("\n" + "="*80)
        print("LEVEL 3: BUSINESS METRICS EVALUATION")
        print("="*80)
        
        df = self.system.df_processed
        test_indices = np.random.choice(len(df), min(n_samples, len(df)), replace=False)
        
        tiv_differences = []
        revenue_differences = []
        employee_differences = []
        tiv_within_20pct = []
        revenue_within_30pct = []
        
        for idx in test_indices:
            query_policy = df.iloc[idx:idx+1]
            
            result = self.system.find_similar(
                query_policy,
                numerical_features=['policy_tiv', 'Revenue', 'EMP_TOT'],
                categorical_features=['Product'],
                top_n=3,
                explain=False
            )
            
            query_tiv = df.iloc[idx]['policy_tiv']
            query_revenue = df.iloc[idx]['Revenue']
            query_employees = df.iloc[idx]['EMP_TOT']
            
            for policy in result['similar_policies']:
                # TIV similarity
                tiv_diff = abs(policy['policy_tiv'] - query_tiv) / query_tiv
                tiv_differences.append(tiv_diff)
                tiv_within_20pct.append(1 if tiv_diff <= 0.2 else 0)
                
                # Revenue similarity
                rev_diff = abs(policy['revenue'] - query_revenue) / query_revenue
                revenue_differences.append(rev_diff)
                revenue_within_30pct.append(1 if rev_diff <= 0.3 else 0)
                
                # Employee similarity
                emp_diff = abs(policy['employees'] - query_employees) / (query_employees + 1)
                employee_differences.append(emp_diff)
        
        results = {
            'tiv_median_difference': np.median(tiv_differences),
            'tiv_within_20pct': np.mean(tiv_within_20pct),
            'revenue_median_difference': np.median(revenue_differences),
            'revenue_within_30pct': np.mean(revenue_within_30pct),
            'employee_median_difference': np.median(employee_differences)
        }
        
        print(f"\nResults:")
        print(f"  TIV Similarity:")
        print(f"    Median difference:     {results['tiv_median_difference']:.1%}")
        print(f"    Within ±20%:           {results['tiv_within_20pct']:.1%}")
        print(f"\n  Revenue Similarity:")
        print(f"    Median difference:     {results['revenue_median_difference']:.1%}")
        print(f"    Within ±30%:           {results['revenue_within_30pct']:.1%}")
        print(f"\n  Employee Count:")
        print(f"    Median difference:     {results['employee_median_difference']:.1%}")
        
        # Visualize distributions
        self._plot_business_metrics(tiv_differences, revenue_differences, employee_differences)
        
        self.evaluation_results['business'] = results
        return results
    
    def _plot_business_metrics(self, tiv_diffs, rev_diffs, emp_diffs):
        """Plot business metric distributions"""
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(1, 3, figsize=(18, 5))
        
        # TIV differences
        axes[0].hist(tiv_diffs, bins=30, edgecolor='black', alpha=0.7, color='steelblue')
        axes[0].axvline(np.median(tiv_diffs), color='red', linestyle='--', 
                       linewidth=2, label=f'Median: {np.median(tiv_diffs):.1%}')
        axes[0].axvline(0.2, color='green', linestyle=':', linewidth=2, label='±20% threshold')
        axes[0].set_xlabel('Relative TIV Difference', fontsize=12)
        axes[0].set_ylabel('Frequency', fontsize=12)
        axes[0].set_title('TIV Similarity Distribution', fontsize=14, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Revenue differences
        axes[1].hist(rev_diffs, bins=30, edgecolor='black', alpha=0.7, color='seagreen')
        axes[1].axvline(np.median(rev_diffs), color='red', linestyle='--',
                       linewidth=2, label=f'Median: {np.median(rev_diffs):.1%}')
        axes[1].axvline(0.3, color='green', linestyle=':', linewidth=2, label='±30% threshold')
        axes[1].set_xlabel('Relative Revenue Difference', fontsize=12)
        axes[1].set_ylabel('Frequency', fontsize=12)
        axes[1].set_title('Revenue Similarity Distribution', fontsize=14, fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # Employee differences
        axes[2].hist(emp_diffs, bins=30, edgecolor='black', alpha=0.7, color='coral')
        axes[2].axvline(np.median(emp_diffs), color='red', linestyle='--',
                       linewidth=2, label=f'Median: {np.median(emp_diffs):.1%}')
        axes[2].set_xlabel('Relative Employee Difference', fontsize=12)
        axes[2].set_ylabel('Frequency', fontsize=12)
        axes[2].set_title('Employee Count Similarity', fontsize=14, fontweight='bold')
        axes[2].legend()
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('business_metrics_evaluation.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        print(f"\n✓ Visualization saved: business_metrics_evaluation.png")
    
    def generate_evaluation_report(self) -> str:
        """
        Generate comprehensive evaluation report
        """
        report = f"""
{'='*80}
INSURANCE POLICY SIMILARITY SYSTEM - EVALUATION REPORT
{'='*80}

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

EXECUTIVE SUMMARY
{'─'*80}

This report evaluates the performance of the hybrid policy similarity matching
system across clustering quality, matching consistency, and business metrics.

{'='*80}
1. CLUSTERING QUALITY
{'='*80}

Metric                          Value       Assessment
{'─'*80}
Silhouette Score                {self.evaluation_results['clustering']['silhouette_score']:.3f}       {'✓ Excellent' if self.evaluation_results['clustering']['silhouette_score'] > 0.5 else '○ Good'}
Davies-Bouldin Index            {self.evaluation_results['clustering']['davies_bouldin_index']:.3f}       {'✓ Excellent' if self.evaluation_results['clustering']['davies_bouldin_index'] < 1.0 else '○ Good'}
Calinski-Harabasz Score         {self.evaluation_results['clustering']['calinski_harabasz_score']:.1f}     ✓ Good
Number of Clusters              {self.evaluation_results['clustering']['n_clusters']}           ✓

Interpretation:
The clustering algorithm successfully identified {self.evaluation_results['clustering']['n_clusters']} distinct policy
segments with {'strong' if self.evaluation_results['clustering']['silhouette_score'] > 0.5 else 'moderate'} separation between clusters.

{'='*80}
2. SIMILARITY MATCHING CONSISTENCY
{'='*80}

Metric                          Value       Target      Status
{'─'*80}
Cluster Consistency             {self.evaluation_results['similarity']['cluster_consistency_mean']:.1%}       >70%        {'✓ PASS' if self.evaluation_results['similarity']['cluster_consistency_mean'] > 0.7 else '✗ FAIL'}
Product Consistency             {self.evaluation_results['similarity']['product_consistency_mean']:.1%}       >60%        {'✓ PASS' if self.evaluation_results['similarity']['product_consistency_mean'] > 0.6 else '✗ FAIL'}
Industry Consistency            {self.evaluation_results['similarity']['industry_consistency_mean']:.1%}       >60%        {'✓ PASS' if self.evaluation_results['similarity']['industry_consistency_mean'] > 0.6 else '✗ FAIL'}
Avg Similarity Score            {self.evaluation_results['similarity']['avg_similarity_score']:.3f}       >0.70       {'✓ PASS' if self.evaluation_results['similarity']['avg_similarity_score'] > 0.7 else '✗ FAIL'}

Interpretation:
The system demonstrates {'strong' if self.evaluation_results['similarity']['cluster_consistency_mean'] > 0.7 else 'moderate'} consistency in matching policies within
the same cluster and product categories.

{'='*80}
3. BUSINESS METRICS
{'='*80}

Metric                          Value       Target      Status
{'─'*80}
TIV Median Difference           {self.evaluation_results['business']['tiv_median_difference']:.1%}       <25%        {'✓ PASS' if self.evaluation_results['business']['tiv_median_difference'] < 0.25 else '✗ FAIL'}
TIV Within ±20%                 {self.evaluation_results['business']['tiv_within_20pct']:.1%}       >50%        {'✓ PASS' if self.evaluation_results['business']['tiv_within_20pct'] > 0.5 else '✗ FAIL'}
Revenue Median Difference       {self.evaluation_results['business']['revenue_median_difference']:.1%}       <35%        {'✓ PASS' if self.evaluation_results['business']['revenue_median_difference'] < 0.35 else '✗ FAIL'}
Revenue Within ±30%             {self.evaluation_results['business']['revenue_within_30pct']:.1%}       >50%        {'✓ PASS' if self.evaluation_results['business']['revenue_within_30pct'] > 0.5 else '✗ FAIL'}
Employee Median Difference      {self.evaluation_results['business']['employee_median_difference']:.1%}       <40%        {'✓ PASS' if self.evaluation_results['business']['employee_median_difference'] < 0.4 else '✗ FAIL'}

Interpretation:
Similar policies show {'strong' if self.evaluation_results['business']['tiv_within_20pct'] > 0.6 else 'moderate'} alignment on key business metrics,
making them suitable for underwriting comparison.

{'='*80}
RECOMMENDATIONS
{'='*80}

1. Model Performance: {'PRODUCTION READY' if all([
    self.evaluation_results['clustering']['silhouette_score'] > 0.4,
    self.evaluation_results['similarity']['cluster_consistency_mean'] > 0.6,
    self.evaluation_results['business']['tiv_within_20pct'] > 0.4
]) else 'NEEDS TUNING'}

2. Suggested Actions:
   • {'✓' if self.evaluation_results['similarity']['cluster_consistency_mean'] > 0.7 else '→'} Deploy to production environment
   • {'✓' if self.evaluation_results['business']['tiv_within_20pct'] > 0.6 else '→'} A/B test with underwriters
   • → Collect user feedback for continuous improvement
   • → Monitor performance metrics monthly

3. Areas for Improvement:
"""
        
        # Add specific recommendations
        if self.evaluation_results['clustering']['silhouette_score'] < 0.5:
            report += "   • Consider adjusting number of clusters or feature weights\n"
        if self.evaluation_results['similarity']['product_consistency_mean'] < 0.7:
            report += "   • Increase weight on semantic embeddings (β parameter)\n"
        if self.evaluation_results['business']['tiv_within_20pct'] < 0.6:
            report += "   • Fine-tune numerical feature scaling\n"
        
        report += f"\n{'='*80}\n"
        
        return report
    
    def run_full_evaluation(self, n_samples: int = 200) -> Dict:
        """
        Run complete evaluation pipeline
        """
        print("\n" + "="*80)
        print("RUNNING COMPREHENSIVE EVALUATION")
        print("="*80)
        
        # Run all evaluations
        self.evaluate_clustering_quality()
        self.evaluate_similarity_matching(n_samples)
        self.evaluate_business_metrics(n_samples)
        
        # Generate report
        report = self.generate_evaluation_report()
        
        # Save report
        with open('evaluation_report.txt', 'w') as f:
            f.write(report)
        
        print("\n" + report)
        print("\n✓ Full report saved: evaluation_report.txt")
        
        return self.evaluation_results


# Usage
evaluator = ModelEvaluator(system)
results = evaluator.run_full_evaluation(n_samples=200)
```

---

## 🔍 SHAP Explainability Deep Dive

### Visual Explanations

```python
def create_shap_explanations(system, sample_policy):
    """
    Generate comprehensive SHAP visualizations
    """
    import matplotlib.pyplot as plt
    
    # Get prediction
    result = system.find_similar(
        sample_policy,
        numerical_features,
        categorical_features,
        top_n=3,
        explain=True
    )
    
    predicted_cluster = result['predicted_cluster']
    
    # Preprocess sample
    X_num, X_emb, _ = system.preprocessor.fit_transform(
        pd.DataFrame([sample_policy]),
        numerical_features,
        categorical_features
    )
    X_combined = np.hstack([
        system.pca_numerical.transform(X_num),
        system.pca_embeddings.transform(X_emb)
    ])
    
    # Compute SHAP values
    shap_values = system.shap_explainer.shap_values(X_combined)
    
    # 1. Waterfall plot - individual prediction
    plt.figure(figsize=(12, 8))
    shap.waterfall_plot(
        shap.Explanation(
            values=shap_values[predicted_cluster][0],
            base_values=system.shap_explainer.expected_value[predicted_cluster],
            data=X_combined[0],
            feature_names=[f'Feature {i}' for i in range(X_combined.shape[1])]
        ),
        max_display=15,
        show=False
    )
    plt.title(f'Why This Policy → Cluster {predicted_cluster}', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('shap_waterfall.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 2. Force plot - visual explanation
    shap.force_plot(
        system.shap_explainer.expected_value[predicted_cluster],
        shap_values[predicted_cluster][0],
        X_combined[0],
        matplotlib=True,
        show=False
    )
    plt.savefig('shap_force.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 3. Feature importance summary
    feature_importance = pd.DataFrame({
        'feature_idx': range(X_combined.shape[1]),
        'importance': np.abs(shap_values[predicted_cluster][0])
    }).sort_values('importance', ascending=False).head(20)
    
    plt.figure(figsize=(10, 8))
    plt.barh(range(len(feature_importance)), feature_importance['importance'])
    plt.yticks(range(len(feature_importance)), 
               [f'Feature {idx}' for idx in feature_importance['feature_idx']])
    plt.xlabel('Absolute SHAP Value', fontsize=12)
    plt.title('Top 20 Feature Importance for Prediction', fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.tight_layout()
    plt.savefig('shap_importance.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("✓ SHAP visualizations saved:")
    print("  - shap_waterfall.png")
    print("  - shap_force.png")
    print("  - shap_importance.png")
```

---

## 📈 Production Monitoring Metrics

### Real-Time Dashboard Metrics

```python
class ProductionMonitor:
    """
    Monitor system performance in production
    """
    
    def __init__(self):
        self.predictions = []
        self.feedback = []
    
    def log_prediction(self, query, result, timestamp=None):
        """Log each prediction for monitoring"""
        self.predictions.append({
            'timestamp': timestamp or datetime.now(),
            'query_tiv': query['policy_tiv'],
            'predicted_cluster': result['predicted_cluster'],
            'top_similarity_score': result['similar_policies'][0]['overall_score'],
            'same_cluster_matches': sum(1 for p in result['similar_policies'] 
                                       if p['same_cluster'])
        })
    
    def log_feedback(self, prediction_id, useful, reason=None):
        """Log underwriter feedback"""
        self.feedback.append({
            'timestamp': datetime.now(),
            'prediction_id': prediction_id,
            'useful': useful,
            'reason': reason
        })
    
    def get_metrics(self, days=7):
        """Get metrics for last N days"""
        cutoff = datetime.now() - timedelta(days=days)
        recent = [p for p in self.predictions if p['timestamp'] > cutoff]
        
        if not recent:
            return {}
        
        metrics = {
            'total_predictions': len(recent),
            'avg_similarity_score': np.mean([p['top_similarity_score'] for p in recent]),
            'cluster_match_rate': np.mean([p['same_cluster_matches'] / 3 for p in recent]),
            'predictions_per_day': len(recent) / days
        }
        
        # Feedback metrics
        recent_feedback = [f for f in self.feedback 
                          if f['timestamp'] > cutoff]
        if recent_feedback:
            metrics['user_satisfaction'] = np.mean([f['useful'] for f in recent_feedback])
            metrics['total_feedback'] = len(recent_feedback)
        
        return metrics
```

---

## ✅ Production Readiness Checklist

```
TECHNICAL REQUIREMENTS
□ Silhouette score > 0.40
□ Cluster consistency > 60%
□ TIV similarity within ±25%
□ API response time < 2 seconds
□ Error handling implemented
□ Logging configured

BUSINESS REQUIREMENTS
□ Underwriter validation (≥10 test cases)
□ Product owner approval
□ Documentation complete
□ Training materials prepared
□ Rollout plan defined

OPERATIONAL REQUIREMENTS  
□ Monitoring dashboard deployed
□ Alert thresholds configured
□ Backup system in place
□ Rollback plan documented
□ Support team trained
```

---

*Part 4 (Final): Complete Production Code + Deployment Guide coming next!*

#MachineLearning #Insurance #ModelValidation #SHAP #Explainability
